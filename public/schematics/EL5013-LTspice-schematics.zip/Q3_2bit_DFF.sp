* Q3_2bit_DFF: exported from wired ASC connectivity
XCLK clk cb vdd 0 INV
XFF0 d0 clk cb q0 qb0 vdd 0 DFF
XFF1 d1 clk cb q1 qb1 vdd 0 DFF
VDD vdd 0 1.8
Cq0 q0 0 12f
Cq1 q1 0 12f
Cqb0 qb0 0 12f
Cqb1 qb1 0 12f
.options method=gear solver=alt
VCLK clk 0 PULSE(0 1.8 10n 20p 20p 10n 20n)
VD0 d0 0 PWL(0.00000n 0 4.99000n 0 5.01000n 1.8 14.99000n 1.8 15.01000n 0 24.99000n 0 25.01000n 0 34.99000n 0 35.01000n 1.8 44.99000n 1.8 45.01000n 1.8 54.99000n 1.8 55.01000n 0 64.99000n 0 65.01000n 1.8 74.99000n 1.8 75.01000n 0 84.99000n 0 85.01000n 0)
VD1 d1 0 PWL(0.00000n 0 4.99000n 0 5.01000n 0 14.99000n 0 15.01000n 1.8 24.99000n 1.8 25.01000n 1.8 34.99000n 1.8 35.01000n 0 44.99000n 0 45.01000n 1.8 54.99000n 1.8 55.01000n 0 64.99000n 0 65.01000n 0 74.99000n 0 75.01000n 1.8 84.99000n 1.8 85.01000n 0)
.tran 0 100n 0 1p
.save V(vdd) V(clk) V(cb) V(d0) V(d1) V(q0) V(q1) V(qb0) V(qb1) I(VDD)
.meas tran tcq0_r TRIG V(clk) VAL=0.9 RISE=3 TARG V(q0) VAL=0.9 TD=40n RISE=1
.meas tran tcq0_f TRIG V(clk) VAL=0.9 RISE=2 TARG V(q0) VAL=0.9 TD=20n FALL=1
.meas tran tcq1_r TRIG V(clk) VAL=0.9 RISE=2 TARG V(q1) VAL=0.9 RISE=1
.meas tran tcq1_f TRIG V(clk) VAL=0.9 RISE=4 TARG V(q1) VAL=0.9 TD=60n FALL=1

.subckt INV a y vp vn
MP y a vp vp PM W=5u L=0.18u
MN y a vn vn NM W=2u L=0.18u
.ends
.subckt TG a y en eb vp vn
MN y en a vn NM W=2u L=0.18u
MP y eb a vp PM W=5u L=0.18u
.ends
.subckt DFF d clk cb q qb vp vn
XM d m cb clk vp vn TG
XI1 m mb vp vn INV
XI2 mb mq vp vn INV
XMF mq m clk cb vp vn TG
XS mq s clk cb vp vn TG
XI3 s qb vp vn INV
XI4 qb q vp vn INV
XSF q s cb clk vp vn TG
.ends
.subckt XOR a b y vp vn
XA a ab vp vn INV
XB b bb vp vn INV
XT0 b x ab a vp vn TG
XT1 bb x a ab vp vn TG
XI0 x xb vp vn INV
XI1 xb y vp vn INV
.ends
.subckt NAND a b y vp vn
MP1 y a vp vp PM W=5u L=0.18u
MP2 y b vp vp PM W=5u L=0.18u
MN1 y a n vn NM W=4u L=0.18u
MN2 n b vn vn NM W=4u L=0.18u
.ends
.subckt FA a b ci s co vp vn
XP a b p vp vn XOR
XS p ci s vp vn XOR
XG a b ng vp vn NAND
XC p ci nc vp vn NAND
XO ng nc co vp vn NAND
.ends
.model NM NMOS LEVEL=1 VTO=0.55 KP=200u LAMBDA=0.02 GAMMA=0.4 PHI=0.7 TOX=4n CGSO=0.3n CGDO=0.3n CBD=0.5f CBS=0.5f
.model PM PMOS LEVEL=1 VTO=-0.55 KP=80u LAMBDA=0.02 GAMMA=0.4 PHI=0.7 TOX=4n CGSO=0.3n CGDO=0.3n CBD=0.5f CBS=0.5f
.temp 27
.options plotwinsize=0 reltol=0.001 itl4=100 cshunt=1f

.end
