* Q2_path_A3: exported from wired ASC connectivity
MPA p a vdd vdd PM W=7.5u L=0.18u
MPB p b vdd vdd PM W=7.5u L=0.18u
MPC out c p vdd PM W=5u L=0.18u
MPD N25 d p vdd PM W=7.5u L=0.18u
MPE out e N25 vdd PM W=7.5u L=0.18u
MNA out a N26 0 NM W=2u L=0.18u
MNB N26 b 0 0 NM W=2u L=0.18u
MNC out c N27 0 NM W=2u L=0.18u
MND N27 d 0 0 NM W=2u L=0.18u
MNE N27 e 0 0 NM W=2u L=0.18u
VDD vdd 0 1.8
Cload out 0 20f
Vb b 0 1.8
Vc c 0 1.8
Vd d 0 0.0
Ve e 0 0.0
Va a 0 PULSE(0 1.8 5n 20p 20p 5n 10n)
.tran 0 25n 0 1p
.save V(vdd) V(a) V(out) I(VDD)
.meas tran tphl TRIG V(a) VAL=0.9 RISE=1 TARG V(out) VAL=0.9 FALL=1
.meas tran tplh TRIG V(a) VAL=0.9 FALL=1 TARG V(out) VAL=0.9 RISE=1
.meas tran tr TRIG V(out) VAL=0.18 RISE=1 TARG V(out) VAL=1.62 RISE=1
.meas tran tf TRIG V(out) VAL=1.62 FALL=1 TARG V(out) VAL=0.18 FALL=1

.subckt INV a y vp vn
MP y a vp vp PM W=5u L=0.18u
MN y a vn vn NM W=2u L=0.18u
.ends
.subckt TG a y en eb vp vn
MN y en a vn NM W=2u L=0.18u
MP y eb a vp PM W=5u L=0.18u
.ends
.subckt DFF d clk cb q qb vp vn
XM d m cb clk vp vn TG
XI1 m mb vp vn INV
XI2 mb mq vp vn INV
XMF mq m clk cb vp vn TG
XS mq s clk cb vp vn TG
XI3 s qb vp vn INV
XI4 qb q vp vn INV
XSF q s cb clk vp vn TG
.ends
.subckt XOR a b y vp vn
XA a ab vp vn INV
XB b bb vp vn INV
XT0 b x ab a vp vn TG
XT1 bb x a ab vp vn TG
XI0 x xb vp vn INV
XI1 xb y vp vn INV
.ends
.subckt NAND a b y vp vn
MP1 y a vp vp PM W=5u L=0.18u
MP2 y b vp vp PM W=5u L=0.18u
MN1 y a n vn NM W=4u L=0.18u
MN2 n b vn vn NM W=4u L=0.18u
.ends
.subckt FA a b ci s co vp vn
XP a b p vp vn XOR
XS p ci s vp vn XOR
XG a b ng vp vn NAND
XC p ci nc vp vn NAND
XO ng nc co vp vn NAND
.ends
.model NM NMOS LEVEL=1 VTO=0.55 KP=200u LAMBDA=0.02 GAMMA=0.4 PHI=0.7 TOX=4n CGSO=0.3n CGDO=0.3n CBD=0.5f CBS=0.5f
.model PM PMOS LEVEL=1 VTO=-0.55 KP=80u LAMBDA=0.02 GAMMA=0.4 PHI=0.7 TOX=4n CGSO=0.3n CGDO=0.3n CBD=0.5f CBS=0.5f
.temp 27
.options plotwinsize=0 reltol=0.001 itl4=100 cshunt=1f

.end
