* Q4_carry: exported from wired ASC connectivity
XFA0 a0 b0 cin s0 c1 vdd 0 FA
XFA1 a1 b1 c1 s1 c2 vdd 0 FA
XFA2 a2 b2 c2 s2 c3 vdd 0 FA
XFA3 a3 b3 c3 s3 cout vdd 0 FA
VDD vdd 0 1.8
CS0 s0 0 20f
CS1 s1 0 20f
CS2 s2 0 20f
CS3 s3 0 20f
CC cout 0 20f
VA0 a0 0 1.8
VB0 b0 0 0
VA1 a1 0 1.8
VB1 b1 0 0
VA2 a2 0 1.8
VB2 b2 0 0
VA3 a3 0 1.8
VB3 b3 0 0
VCIN cin 0 PULSE(0 1.8 5n 20p 20p 5n 10n)
.tran 0 55n 0 1p
.save V(vdd) V(cin) V(c1) V(c2) V(c3) V(cout) V(s0) V(s1) V(s2) V(s3) I(VDD)
.meas tran delay_r TRIG V(cin) VAL=0.9 RISE=2 TARG V(cout) VAL=0.9 RISE=2
.meas tran delay_f TRIG V(cin) VAL=0.9 FALL=2 TARG V(cout) VAL=0.9 FALL=2
.meas tran pavg AVG (-V(vdd)*I(VDD)) FROM=15n TO=55n
.meas tran pstatic AVG (-V(vdd)*I(VDD)) FROM=18n TO=19n

.subckt INV a y vp vn
MP y a vp vp PM W=5u L=0.18u
MN y a vn vn NM W=2u L=0.18u
.ends
.subckt TG a y en eb vp vn
MN y en a vn NM W=2u L=0.18u
MP y eb a vp PM W=5u L=0.18u
.ends
.subckt DFF d clk cb q qb vp vn
XM d m cb clk vp vn TG
XI1 m mb vp vn INV
XI2 mb mq vp vn INV
XMF mq m clk cb vp vn TG
XS mq s clk cb vp vn TG
XI3 s qb vp vn INV
XI4 qb q vp vn INV
XSF q s cb clk vp vn TG
.ends
.subckt XOR a b y vp vn
XA a ab vp vn INV
XB b bb vp vn INV
XT0 b x ab a vp vn TG
XT1 bb x a ab vp vn TG
XI0 x xb vp vn INV
XI1 xb y vp vn INV
.ends
.subckt NAND a b y vp vn
MP1 y a vp vp PM W=5u L=0.18u
MP2 y b vp vp PM W=5u L=0.18u
MN1 y a n vn NM W=4u L=0.18u
MN2 n b vn vn NM W=4u L=0.18u
.ends
.subckt FA a b ci s co vp vn
XP a b p vp vn XOR
XS p ci s vp vn XOR
XG a b ng vp vn NAND
XC p ci nc vp vn NAND
XO ng nc co vp vn NAND
.ends
.model NM NMOS LEVEL=1 VTO=0.55 KP=200u LAMBDA=0.02 GAMMA=0.4 PHI=0.7 TOX=4n CGSO=0.3n CGDO=0.3n CBD=0.5f CBS=0.5f
.model PM PMOS LEVEL=1 VTO=-0.55 KP=80u LAMBDA=0.02 GAMMA=0.4 PHI=0.7 TOX=4n CGSO=0.3n CGDO=0.3n CBD=0.5f CBS=0.5f
.temp 27
.options plotwinsize=0 reltol=0.001 itl4=100 cshunt=1f

.end
